% simple script for teaching in Lab 1 (plotsin.m)

x = 0:2*pi/N:2*pi;
y = sin(w*x);
plot(x,y)
